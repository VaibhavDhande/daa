### BT Mini Project  
Use link https://github.com/riya-joshi-401/Ethereum-Blockchain-based-Electronic-Voting-System
